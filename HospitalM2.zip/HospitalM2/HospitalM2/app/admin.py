# admin.py
from django.contrib import admin
from .models import Doctor, Patient, Appointment

# Register your models here

class DoctorAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'specialty', 'email', 'phone_number', 'created_at')
    search_fields = ('first_name', 'last_name', 'specialty')
    list_filter = ('specialty', 'created_at')
    ordering = ('last_name',)
    
class PatientAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'date_of_birth', 'gender', 'phone_number', 'email')
    search_fields = ('first_name', 'last_name', 'phone_number', 'email')
    list_filter = ('gender', 'date_of_birth')
    ordering = ('last_name',)

class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('doctor', 'date')
    search_fields = ('patient__first_name', 'doctor__first_name', 'status')
    list_filter = ('date',)
    ordering = ('date',)

# Registering models with the admin site
admin.site.register(Doctor, DoctorAdmin)
admin.site.register(Patient, PatientAdmin)
admin.site.register(Appointment, AppointmentAdmin)
