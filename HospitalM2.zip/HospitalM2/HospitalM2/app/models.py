from django.db import models
from datetime import date,time

class Patient(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    date_of_birth = models.DateField()
    gender = models.CharField(max_length=10) 
    phone_number = models.CharField(max_length=15)
    email = models.EmailField()
    address = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.first_name} {self.last_name}'
class Doctor(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    specialty = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15)
    email = models.EmailField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Dr. {self.first_name} {self.last_name} - {self.specialty}'
 
class Appointment(models.Model):
    name = models.CharField(max_length=100,default='Unknown')
    email = models.EmailField(default='default@example.com')
    phone = models.CharField(max_length=15,default='+1234567890')
    # doctor = models.CharField(max_length=200)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    date = models.DateField(default=date.today)
    time = models.TimeField(auto_now=True)

    def __str__(self):
        return f"Appointment for {self.name} with {self.doctor} on {self.date} at {self.time}"