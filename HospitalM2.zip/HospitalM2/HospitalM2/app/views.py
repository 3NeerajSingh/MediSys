from django.shortcuts import render, redirect, get_object_or_404
from .models import Patient,Appointment
import datetime 
from .forms import PatientForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.http import HttpResponse
# Create your views here.
def home(request):
    return render(request,'home.html')
def aboutus(request):
    return render(request,'about.html')
def appointments(request):
    if request.method == 'POST':
        # Retrieve form data
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        doctor = request.POST.get('doctor')
        date = request.POST.get('date')
        time = request.POST.get('time')

        # Basic validation to ensure no fields are empty
        if not name or not email or not phone or not doctor or not date or not time:
            return HttpResponse("All fields are required.", status=400)

        try:
            # Create and save the appointment to the database
            appointment = Appointment(
                name=name,
                email=email,
                phone=phone,
                doctor=doctor,
                date=datetime.datetime.strptime(date, "%Y-%m-%d").date(),
                time=datetime.datetime.strptime(time, "%H:%M").time()
            )
            appointment.save()

            # Redirect to a success page or the appointment list page
            return redirect('appointments')  # Adjust as needed, e.g., 'appointments' could be a URL name for a list view

        except Exception as e:
            return HttpResponse(f"Error: {str(e)}", status=500)
    
    # If GET request, render the form
    return render(request, 'appointments.html')

def contact(request):
    return render(request,'contact.html')
def login_user(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request,'Your Login is Succesfull')
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password')
            return redirect('login')
    return render(request,'login.html')
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Account created successfully!')
            return redirect('login')
        else:
            messages.error(request, 'Registration failed. Please try again.')
    
    else:
        form = UserCreationForm()
    
    return render(request, 'register.html', {'form': form})
def services(request):
    return render(request,'services.html')
def index(request):
    if request.method == 'POST':
        # Get the data from the form submission
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        date_of_birth = request.POST.get('date_of_birth')
        gender = request.POST.get('gender')
        phone_number = request.POST.get('phone_number')
        email = request.POST.get('email')
        address = request.POST.get('address')

        # Basic validation (ensure fields are not empty, add more if needed)
        if not first_name or not last_name or not date_of_birth or not gender:
            return HttpResponse("All fields are required.", status=400)

        try:
            # Create the Patient object and save it to the database
            patient = Patient(
                first_name=first_name,
                last_name=last_name,
                date_of_birth=date_of_birth,
                gender=gender,
                phone_number=phone_number,
                email=email,
                address=address
            )
            patient.save()  # Save patient to the database

            # Redirect to a patient list or success page
            return redirect('home')
        except Exception as e:
            return HttpResponse(f"Error: {str(e)}", status=500)
    else:
        # If GET request, render the form to the user
        return render(request, 'index.html')
def logout_user(request):
    logout(request)
    return render(request,'home.html')